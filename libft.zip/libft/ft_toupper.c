/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_toupper.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fciapett <fciapett@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/03 12:42:08 by fciapett          #+#    #+#             */
/*   Updated: 2024/12/09 11:10:10 by fciapett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int     ft_toupper(int ch)
{
        if (ch >= 'a' && ch <= 'z')
                return (ch - 32);
        return(ch);
}
/* 
#include <ctype.h>
#include <stdio.h>
#include <unistd.h>

int     main()
{       
        char c = 'b';

        printf("Carattere: %c \n", c);
        printf("Function creata: %c \n", ft_toupper(c));
        printf("Function originale: %c", toupper(c));
        return 0;
} */