/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fciapett <fciapett@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/09 11:16:27 by fciapett          #+#    #+#             */
/*   Updated: 2024/12/09 11:48:31 by fciapett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char    *ft_strchr(char *str, int ch)
{
        while (*str)
        {
                if (*str == ch)
                        return(str);
                str++;
        }
        return (0);
}

/* #include <ctype.h>
#include <stdio.h>
#include <unistd.h>

int     main()
{
        char    *string = "Comacose?";
        int    c = 'c';
        
        printf("Questo e' il risultato %s", ft_strchr(string, c));
        return (0);
} */