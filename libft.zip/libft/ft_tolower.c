/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tolower.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fciapett <fciapett@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/09 11:12:17 by fciapett          #+#    #+#             */
/*   Updated: 2024/12/09 11:46:25 by fciapett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int    ft_tolower(int ch)
{
        if (ch >= 'A' && ch <= 'B')
                return (ch + 32);
        return(ch);
}

#include <ctype.h>
#include <stdio.h>
#include <unistd.h>

int     main()
{       
        char c = 'B';

        printf("Carattere: %c \n", c);
        printf("Function creata: %c \n", ft_tolower(c));
        printf("Function originale: %c", tolower(c));
        return 0;
}