/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fciapett <fciapett@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/19 21:57:49 by fciapett          #+#    #+#             */
/*   Updated: 2024/12/03 12:41:24 by fciapett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <string.h>

int  ft_strlcat(char *dest, const char *src, int size)
{
    int len_dest;
    int len_src;
    int i;

    i = 0;
    len_dest = 0;
    len_src = 0;

    if (size <= 0)
        return (len_dest + len_src);

    while ()
    

}