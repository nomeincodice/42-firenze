/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fciapett <fciapett@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/09 12:02:19 by fciapett          #+#    #+#             */
/*   Updated: 2024/12/09 12:12:11 by fciapett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char    *ft_strrchr(const char *str, int ch)
{
        int     *last_occur;
        
        last_occur = NULL;
        
        while (*str)
        {
                if (*str == ch)
                {
                        last_occur = ch;
                }
                str++;
        }
        if (ch == '\0')
                return(0);
        else
                return(last_occur);
}

/* #include <ctype.h>
#include <stdio.h>
#include <unistd.h>

int     main()
{
        char    *string = "Comacose?";
        int    c = 'c';
        
        printf("Questo e' il risultato %s", ft_strrchr(string, c));
        return (0);
} */