/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fciapett <fciapett@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/03 11:35:04 by fciapett          #+#    #+#             */
/*   Updated: 2024/12/03 12:14:03 by fciapett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

void    *ft_memmove(void *dest, const void *src, size_t n)
{
        char *d = (char *) dest;
        const char *s = (const char *) src;
        size_t i;

        i = 0;
        if( d == s || n ==  0)
        {
                return (dest);
        }
        if (i < n)
        {
                d[i] = s[i];
                i++;
        }
        else
        {
                size_t i = n;
                while (i > 0)
                {
                        i--;
                        d[i] = s[i];
                }
        }
        return (dest);
}
/* int main() {
    char array[] = "Hello World";
    
    ft_memmove(array, array + 4, 2);
    array[5] = '\0';
    
    printf("Risultato: %s\n", array);
    return 0;
} */
