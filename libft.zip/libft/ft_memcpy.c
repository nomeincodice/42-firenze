/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fciapett <fciapett@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/03 10:55:50 by fciapett          #+#    #+#             */
/*   Updated: 2024/12/03 11:33:47 by fciapett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

void    *ft_memcpy(void *dest, void *src, size_t n)
{
        char *d = (char *)dest;
        const  char *s = (const char *)src;
        size_t i;
        
        i = 0;
        while (i < n)
        {
                d[i] = s[i];
                i++;
        }
        return (dest);
}

/* int main()
{
    char src[] = "Hello";
    char dest[6];
    ft_memcpy(dest, src, sizeof(src));
    printf("%s\n", dest);
    return 0;
} */
